#!/bin/bash

# Set exit on error
set -e

echo "🚀 Preparing DLA E-commerce app for export..."

# Create export directory if it doesn't exist
EXPORT_DIR="dla-ecommerce-export"
if [ -d "$EXPORT_DIR" ]; then
  echo "🧹 Cleaning up previous export directory..."
  rm -rf "$EXPORT_DIR"
fi

echo "📁 Creating export directory: $EXPORT_DIR"
mkdir -p "$EXPORT_DIR"

# Copy necessary files
echo "📋 Copying project files..."
cp -r client "$EXPORT_DIR/"
cp -r server "$EXPORT_DIR/"
cp -r shared "$EXPORT_DIR/"
cp .env "$EXPORT_DIR/"
cp dotenv-config.js "$EXPORT_DIR/"
cp package.json "$EXPORT_DIR/"
cp package-lock.json "$EXPORT_DIR/"
cp tsconfig.json "$EXPORT_DIR/"
cp vite.config.ts "$EXPORT_DIR/"
cp drizzle.config.ts "$EXPORT_DIR/"
cp postcss.config.js "$EXPORT_DIR/"
cp tailwind.config.ts "$EXPORT_DIR/"
cp theme.json "$EXPORT_DIR/"
cp sqlite.db "$EXPORT_DIR/"

# Create README file with instructions
cat > "$EXPORT_DIR/README.md" << 'EOF'
# DLA E-commerce App

This is a standalone version of the DLA E-commerce application.

## Getting Started

1. Install dependencies:
   ```
   npm install
   ```

2. Configure environment:
   Edit the `.env` file to set your own environment variables, especially:
   - PORT (default 5000)
   - STRIPE_SECRET_KEY (if you want to use Stripe payments)

3. Start the application:
   ```
   npm run start
   ```

4. Access the application:
   Open your browser and navigate to `http://localhost:5000`

## Default Admin Credentials

Username: dheerajadmin
Password: d1234kumar

## Features

- User authentication (login/register)
- Product browsing and ordering
- Shopping cart functionality
- E-wallet integration
- Admin dashboard for:
  - Product management
  - Order processing
  - Bank account management

## Database

The application uses SQLite for data persistence. The database file is `sqlite.db`.

## Payments

- E-wallet payments work out of the box
- Stripe payments require a valid Stripe API key in the .env file
EOF

# Create a custom start script 
cat > "$EXPORT_DIR/start.js" << 'EOF'
import { spawn } from 'child_process';
import fs from 'fs';

// Check if this is the first run
const firstRun = !fs.existsSync('./node_modules');

if (firstRun) {
  console.log('🔍 First run detected, installing dependencies...');
  
  const install = spawn('npm', ['install'], { stdio: 'inherit' });
  
  install.on('close', (code) => {
    if (code !== 0) {
      console.error('❌ Failed to install dependencies');
      process.exit(1);
    }
    
    console.log('✅ Dependencies installed successfully');
    startApp();
  });
} else {
  startApp();
}

function startApp() {
  console.log('🚀 Starting DLA E-commerce application...');
  
  // Start the server
  const server = spawn('node', ['--experimental-specifier-resolution=node', '--loader', 'ts-node/esm', 'server/index.ts'], {
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: 'production' }
  });
  
  server.on('close', (code) => {
    console.log(`⛔ Server process exited with code ${code}`);
  });
  
  // Handle termination signals
  ['SIGINT', 'SIGTERM'].forEach(signal => {
    process.on(signal, () => {
      console.log(`\n🛑 Received ${signal}, shutting down...`);
      server.kill();
      process.exit(0);
    });
  });
}
EOF

# Update package.json in the export directory
echo "📄 Creating custom package.json for export..."
cat > "$EXPORT_DIR/package.json" << 'EOF'
{
  "name": "dla-ecommerce",
  "version": "1.0.0",
  "description": "DLA E-commerce application",
  "type": "module",
  "main": "server/index.ts",
  "scripts": {
    "start": "node --experimental-specifier-resolution=node --loader ts-node/esm start.js",
    "build": "vite build"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "@hookform/resolvers": "latest",
    "@jridgewell/trace-mapping": "latest",
    "@libsql/client": "latest",
    "@neondatabase/serverless": "latest",
    "@radix-ui/react-accordion": "latest",
    "@radix-ui/react-alert-dialog": "latest",
    "@radix-ui/react-aspect-ratio": "latest",
    "@radix-ui/react-avatar": "latest",
    "@radix-ui/react-checkbox": "latest",
    "@radix-ui/react-collapsible": "latest",
    "@radix-ui/react-context-menu": "latest",
    "@radix-ui/react-dialog": "latest",
    "@radix-ui/react-dropdown-menu": "latest",
    "@radix-ui/react-hover-card": "latest",
    "@radix-ui/react-label": "latest",
    "@radix-ui/react-menubar": "latest",
    "@radix-ui/react-navigation-menu": "latest",
    "@radix-ui/react-popover": "latest",
    "@radix-ui/react-progress": "latest",
    "@radix-ui/react-radio-group": "latest",
    "@radix-ui/react-scroll-area": "latest",
    "@radix-ui/react-select": "latest",
    "@radix-ui/react-separator": "latest",
    "@radix-ui/react-slider": "latest",
    "@radix-ui/react-slot": "latest",
    "@radix-ui/react-switch": "latest",
    "@radix-ui/react-tabs": "latest",
    "@radix-ui/react-toast": "latest",
    "@radix-ui/react-toggle": "latest",
    "@radix-ui/react-toggle-group": "latest",
    "@radix-ui/react-tooltip": "latest",
    "@stripe/react-stripe-js": "latest",
    "@stripe/stripe-js": "latest",
    "@tailwindcss/typography": "latest",
    "@tanstack/react-query": "latest",
    "@types/connect-pg-simple": "latest",
    "@types/express": "latest",
    "@types/express-session": "latest",
    "@types/node": "latest",
    "@types/passport": "latest",
    "@types/passport-local": "latest",
    "@types/react": "latest",
    "@types/react-dom": "latest",
    "@types/ws": "latest",
    "@vitejs/plugin-react": "latest",
    "autoprefixer": "latest",
    "better-sqlite3": "latest",
    "class-variance-authority": "latest",
    "clsx": "latest",
    "cmdk": "latest",
    "connect-pg-simple": "latest",
    "date-fns": "latest",
    "dotenv": "latest",
    "drizzle-kit": "latest",
    "drizzle-orm": "latest",
    "drizzle-zod": "latest",
    "embla-carousel-react": "latest",
    "esbuild": "latest",
    "express": "latest",
    "express-session": "latest",
    "framer-motion": "latest",
    "input-otp": "latest",
    "lucide-react": "latest",
    "memorystore": "latest",
    "passport": "latest",
    "passport-local": "latest",
    "postcss": "latest",
    "react": "latest",
    "react-day-picker": "latest",
    "react-dom": "latest",
    "react-hook-form": "latest",
    "react-icons": "latest",
    "react-resizable-panels": "latest",
    "recharts": "latest",
    "stripe": "latest",
    "tailwind-merge": "latest",
    "tailwindcss": "latest",
    "tailwindcss-animate": "latest",
    "ts-node": "latest",
    "tsx": "latest",
    "typescript": "latest",
    "vaul": "latest",
    "vite": "latest",
    "wouter": "latest",
    "ws": "latest",
    "zod": "latest",
    "zod-validation-error": "latest"
  }
}
EOF

# Create a ZIP archive
echo "📦 Creating ZIP archive..."
zip -r "dla-ecommerce-export.zip" "$EXPORT_DIR"

echo "✅ Export completed! Files are available in:"
echo "📁 Directory: $EXPORT_DIR"
echo "📁 ZIP Archive: dla-ecommerce-export.zip"
echo ""
echo "To run the exported app:"
echo "1. Extract the ZIP file (if using the archive)"
echo "2. Navigate to the directory: cd $EXPORT_DIR"
echo "3. Install dependencies: npm install"
echo "4. Start the app: npm start"