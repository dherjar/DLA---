import { IStorage } from "./types";
import session from "express-session";
import createMemoryStore from "memorystore";
import { users, products, bankAccounts, orders, type User, type Product, type BankAccount, type Order, type InsertUser } from "@shared/schema";
import { hashPassword } from "./auth";
import { db } from "./db";
import { eq } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    // Create admin user and initial products on startup
    this.createAdminUser();
    this.createInitialProducts();
  }

  private async createAdminUser() {
    try {
      // Check if admin already exists
      const existingAdmin = await this.getUserByUsername("dheerajadmin");
      if (!existingAdmin) {
        const hashedPassword = await hashPassword("d1234kumar");
        const [adminUser] = await db.insert(users)
          .values({
            username: "dheerajadmin",
            password: hashedPassword,
            role: "admin"
          })
          .returning();

        // Create admin's bank account
        await db.insert(bankAccounts)
          .values({
            userId: adminUser.id,
            bankName: "dla bank",
            cardNumber: "1911616211314900",
            pin: "2009",
            balance: 0
          });

        console.log("Admin user and bank account created successfully");
      }
    } catch (error) {
      console.error("Error creating admin user:", error);
    }
  }

  private async createInitialProducts() {
    try {
      // Check if products already exist
      const existingProducts = await this.getProducts();
      if (existingProducts.length === 0) {
        const productsData = [
          {
            name: "DLA Smart Watch Pro",
            brand: "DLA",
            category: "Wearables",
            description: "Advanced smartwatch with health tracking and notifications",
            priceInr: 15000,
            imageUrl: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg",
            stock: 50
          },
          {
            name: "iPhone 15 Pro",
            brand: "Apple",
            category: "Phones",
            description: "Latest iPhone with A17 Pro chip and advanced camera system",
            priceInr: 120000,
            imageUrl: "https://images.pexels.com/photos/5741603/pexels-photo-5741603.jpeg",
            stock: 30
          },
          {
            name: "DLA Gaming Laptop",
            brand: "DLA",
            category: "Laptops",
            description: "High-performance gaming laptop with RTX 4080",
            priceInr: 150000,
            imageUrl: "https://images.pexels.com/photos/18105/pexels-photo.jpg",
            stock: 20
          },
          {
            name: "MacBook Pro M3",
            brand: "Apple",
            category: "Laptops",
            description: "Latest MacBook with M3 chip for ultimate performance",
            priceInr: 199000,
            imageUrl: "https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg",
            stock: 15
          },
          {
            name: "DLA Smart Security Camera",
            brand: "DLA",
            category: "Smart Home",
            description: "1080p HD security camera with night vision",
            priceInr: 8000,
            imageUrl: "https://images.pexels.com/photos/371949/pexels-photo-371949.jpeg",
            stock: 60
          },
          {
            name: "Sony WH-1000XM5",
            brand: "Sony",
            category: "Audio",
            description: "Premium noise-cancelling headphones",
            priceInr: 35000,
            imageUrl: "https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg",
            stock: 45
          },
          {
            name: "DLA True Wireless Earbuds",
            brand: "DLA",
            category: "Audio",
            description: "Premium wireless earbuds with active noise cancellation",
            priceInr: 12000,
            imageUrl: "https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg",
            stock: 100
          },
          {
            name: "iPad Pro 12.9",
            brand: "Apple",
            category: "Tablets",
            description: "12.9-inch iPad Pro with M2 chip",
            priceInr: 110000,
            imageUrl: "https://images.pexels.com/photos/1334597/pexels-photo-1334597.jpeg",
            stock: 25
          },
          {
            name: "DLA Gaming Monitor",
            brand: "DLA",
            category: "Monitors",
            description: "32-inch 4K gaming monitor with 144Hz refresh rate",
            priceInr: 45000,
            imageUrl: "https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg",
            stock: 30
          },
          {
            name: "ROG Strix Gaming Mouse",
            brand: "ASUS",
            category: "Gaming",
            description: "High-precision gaming mouse with customizable RGB",
            priceInr: 8000,
            imageUrl: "https://images.pexels.com/photos/2115257/pexels-photo-2115257.jpeg",
            stock: 75
          },
          {
            name: "Samsung Galaxy S24",
            brand: "Samsung",
            category: "Phones",
            description: "Flagship Android phone with AI capabilities",
            priceInr: 80000,
            imageUrl: "https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg",
            stock: 40
          },
          {
            name: "DLA Smart Home Hub",
            brand: "DLA",
            category: "Smart Home",
            description: "Central control for all your smart home devices",
            priceInr: 25000,
            imageUrl: "https://images.pexels.com/photos/1034812/pexels-photo-1034812.jpeg",
            stock: 25
          },
          {
            name: "iPhone 15",
            brand: "Apple",
            category: "Phones",
            description: "A16 Bionic chip, Dynamic Island, and USB-C",
            priceInr: 79900,
            imageUrl: "https://images.pexels.com/photos/1647976/pexels-photo-1647976.jpeg",
            stock: 35
          },
          {
            name: "Vision Pro",
            brand: "Apple",
            category: "VR/AR",
            description: "Revolutionary spatial computing device with advanced eye and hand tracking",
            priceInr: 299999,
            imageUrl: "https://images.pexels.com/photos/2007647/pexels-photo-2007647.jpeg",
            stock: 15
          },
          {
            name: "DLA AR Glasses",
            brand: "DLA",
            category: "VR/AR",
            description: "Lightweight AR glasses with all-day battery life and holographic display",
            priceInr: 149999,
            imageUrl: "https://images.pexels.com/photos/3761124/pexels-photo-3761124.jpeg",
            stock: 25
          },
          {
            name: "iPhone 16 Pro Max",
            brand: "Apple",
            category: "Phones",
            description: "Revolutionary iPhone with advanced AI capabilities, 8K video recording, and 1TB storage",
            priceInr: 179900,
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 20
          },
          {
            name: "iPhone 16 Pro",
            brand: "Apple",
            category: "Phones",
            description: "Latest iPhone featuring quantum image processing and extended battery life",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 25
          },
          {
            name: "Samsung Galaxy S25 Ultra",
            brand: "Samsung",
            category: "Phones",
            description: "Next-gen flagship with 250MP camera and holographic display",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 30
          },
          {
            name: "DLA Quantum Vision Pro",
            brand: "DLA",
            category: "VR/AR",
            description: "Advanced mixed reality headset with neural interface and 8K per eye",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 10
          },
          {
            name: "PlayStation 6",
            brand: "Sony",
            category: "Gaming",
            description: "Next-generation gaming console with 16K graphics and neural feedback",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 15
          },
          {
            name: "DLA Quantum Book",
            brand: "DLA",
            category: "Laptops",
            description: "Revolutionary laptop with quantum processor and holographic keyboard",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 5
          },
          {
            name: "MacBook Pro M4",
            brand: "Apple",
            category: "Laptops",
            description: "Latest MacBook with M4 chip and quantum neural engine",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 20
          },
          {
            name: "DLA Smart Ring",
            brand: "DLA",
            category: "Wearables",
            description: "Advanced smart ring with health monitoring and gesture control",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 50
          },
          {
            name: "Meta Quest 4",
            brand: "Meta",
            category: "VR/AR",
            description: "Next-gen VR headset with mixed reality and neural tracking",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 25
          },
          {
            name: "DLA Fusion Tablet",
            brand: "DLA",
            category: "Tablets",
            description: "Revolutionary tablet with folding 4K OLED and neural stylus",
            imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500&auto=format&fit=crop&q=60",
            stock: 15
          }
        ];

        await db.insert(products).values(productsData);
        console.log("Initial products created successfully");
      }
    } catch (error) {
      console.error("Error creating initial products:", error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Product operations
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: Omit<Product, "id">): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    try {
      const result = await db
        .delete(products)
        .where(eq(products.id, id))
        .returning();
      return result.length > 0;
    } catch (error) {
      console.error("Error deleting product:", error);
      return false;
    }
  }

  async updateProductDiscount(id: number, discount: number): Promise<Product | undefined> {
    try {
      const [updatedProduct] = await db
        .update(products)
        .set({ discount })
        .where(eq(products.id, id))
        .returning();
      return updatedProduct;
    } catch (error) {
      console.error("Error updating product discount:", error);
      return undefined;
    }
  }


  // Bank Account operations
  async getBankAccounts(userId: number): Promise<BankAccount[]> {
    return await db.select().from(bankAccounts).where(eq(bankAccounts.userId, userId));
  }

  async getAllBankAccounts(): Promise<BankAccount[]> {
    return await db.select().from(bankAccounts);
  }

  async createBankAccount(account: Omit<BankAccount, "id">): Promise<BankAccount> {
    const [newAccount] = await db.insert(bankAccounts).values(account).returning();
    return newAccount;
  }

  async updateBankAccountBalance(id: number, balance: number): Promise<BankAccount | undefined> {
    const [updatedAccount] = await db
      .update(bankAccounts)
      .set({ balance })
      .where(eq(bankAccounts.id, id))
      .returning();
    return updatedAccount;
  }

  async getBankAccount(id: number): Promise<BankAccount | undefined> {
    const [account] = await db.select().from(bankAccounts).where(eq(bankAccounts.id, id));
    return account;
  }

  // Order operations
  async createOrder(order: Omit<Order, "id">): Promise<Order> {
    // Stringify the items array and ensure createdAt is a timestamp
    const orderToInsert = {
      ...order,
      items: JSON.stringify(order.items),
      createdAt: Math.floor(Date.now() / 1000) // Convert to Unix timestamp
    };

    const [newOrder] = await db.insert(orders).values(orderToInsert).returning();

    // Parse the items back to an object when returning
    return {
      ...newOrder,
      items: JSON.parse(newOrder.items as string)
    };
  }

  async getOrders(userId?: number): Promise<Order[]> {
    try {
      let result;
      if (userId) {
        result = await db.select().from(orders).where(eq(orders.userId, userId));
      } else {
        result = await db.select().from(orders);
      }

      // Parse the items JSON string for each order
      return result.map(order => ({
        ...order,
        items: typeof order.items === 'string' ? JSON.parse(order.items) : order.items
      }));
    } catch (error) {
      console.error("Error fetching orders:", error);
      return [];
    }
  }

  async getOrder(id: number): Promise<Order | undefined> {
    try {
      const result = await db.select().from(orders).where(eq(orders.id, id));
      const order = result[0];
      if (!order) return undefined;

      return {
        ...order,
        items: typeof order.items === 'string' ? JSON.parse(order.items) : order.items
      };
    } catch (error) {
      console.error("Error fetching order:", error);
      return undefined;
    }
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    try {
      const result = await db
        .update(orders)
        .set({ status })
        .where(eq(orders.id, id))
        .returning();

      const updatedOrder = result[0];
      if (!updatedOrder) return undefined;

      return {
        ...updatedOrder,
        items: typeof updatedOrder.items === 'string' ? JSON.parse(updatedOrder.items) : updatedOrder.items
      };
    } catch (error) {
      console.error("Error updating order status:", error);
      return undefined;
    }
  }
}

export const storage = new DatabaseStorage();