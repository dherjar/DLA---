// Load environment variables from .env file
import * as dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import fs from 'fs';

// Get the directory of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Path to .env file
const envPath = resolve(__dirname, '.env');

// Check if .env file exists and load it
if (fs.existsSync(envPath)) {
  console.log(`Loading environment variables from ${envPath}`);
  dotenv.config({ path: envPath });
} else {
  console.log('No .env file found, using environment variables as is');
}

// Set default port if not specified
if (!process.env.PORT) {
  process.env.PORT = '5000';
  console.log('PORT not specified in environment, defaulting to 5000');
}

// In exported app, make sure Stripe key is available or show warning
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('\x1b[33mWARNING: STRIPE_SECRET_KEY not set in environment variables\x1b[0m');
  console.warn('\x1b[33mPayments with Stripe will not work until this is configured\x1b[0m');
}

export default dotenv;