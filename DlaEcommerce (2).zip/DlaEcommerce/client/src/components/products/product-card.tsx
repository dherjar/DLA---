import { Product, INR_TO_ORES_RATE } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import type { CartItem } from "@/types/cart";

export default function ProductCard({ product }: { product: Product }) {
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  const [imageError, setImageError] = useState(false);

  // Calculate discounted price
  const discountedPriceInr = product.discount > 0 
    ? Math.round(product.priceInr * (1 - product.discount / 100))
    : product.priceInr;
  const priceInOres = Math.round(discountedPriceInr * INR_TO_ORES_RATE);

  const addToCart = () => {
    setIsAdding(true);
    try {
      const cart: CartItem[] = JSON.parse(localStorage.getItem("cart") || "[]");
      const existingItem = cart.find(item => item.productId === product.id);

      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({
          productId: product.id,
          name: product.name,
          brand: product.brand,
          priceInr: discountedPriceInr,
          quantity: 1,
          imageUrl: product.imageUrl,
        });
      }

      localStorage.setItem("cart", JSON.stringify(cart));
      window.dispatchEvent(new Event("cartUpdated"));

      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add item to cart",
        variant: "destructive",
      });
    }
    setIsAdding(false);
  };

  return (
    <Card className="overflow-hidden">
      <div className="aspect-square overflow-hidden relative">
        {!imageError ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="object-cover w-full h-full transition-transform hover:scale-105"
            onError={(e) => {
              console.error(`Failed to load image for ${product.name}:`, product.imageUrl);
              setImageError(true);
              const target = e.target as HTMLImageElement;
              // Use a different fallback approach - free generic product images
              const fallbackImages = [
                "https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg",
                "https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg", 
                "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg",
                "https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg"
              ];
              // Choose a fallback image based on product id or randomly if id is not available
              const index = product.id ? (product.id % fallbackImages.length) : Math.floor(Math.random() * fallbackImages.length);
              target.src = fallbackImages[index];
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted">
            <span className="text-muted-foreground text-sm text-center p-4">
              {product.name}
            </span>
          </div>
        )}
      </div>
      <CardHeader>
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="line-clamp-2">{product.name}</CardTitle>
          <div className="flex flex-col items-end gap-1">
            <Badge variant={product.brand === "DLA" ? "default" : "secondary"}>
              {product.brand}
            </Badge>
            {product.discount > 0 && (
              <Badge variant="destructive">
                {product.discount}% OFF
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-2">{product.description}</p>
        <div className="flex justify-between items-center">
          <div>
            <p className="text-lg font-bold">{priceInOres} Ores</p>
            {product.discount > 0 && (
              <p className="text-sm text-muted-foreground line-through">
                ₹{product.priceInr} ({Math.round(product.priceInr * INR_TO_ORES_RATE)} Ores)
              </p>
            )}
            <p className="text-sm text-muted-foreground">₹{discountedPriceInr}</p>
          </div>
          <Badge variant={product.stock > 0 ? "default" : "destructive"}>
            {product.stock > 0 ? "In Stock" : "Out of Stock"}
          </Badge>
        </div>
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          onClick={addToCart}
          disabled={isAdding || product.stock === 0}
        >
          {isAdding ? "Adding..." : "Add to Cart"}
        </Button>
      </CardFooter>
    </Card>
  );
}