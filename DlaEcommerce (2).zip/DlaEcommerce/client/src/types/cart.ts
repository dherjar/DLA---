export type CartItem = {
  productId: number;
  name: string;
  brand: string;
  priceInr: number;
  quantity: number;
  imageUrl: string;
};